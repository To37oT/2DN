tab = []

tab.append(5)

print(tab[0])
