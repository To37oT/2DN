---
layout: default
title: Accueil
published: true
date: 2024
---

# Cours NSI

[Chapitre 2 - Tableau, tuple et boucle for]({{site.baseurl}}/chapitre2/)<br>
[Chapitre 3 - Les dictionnaires]({{site.baseurl}}/chapitre3/)<br>
