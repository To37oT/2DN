---
layout: default
title: Accueil
published: true
date: 2024
---

# Cours NSI

[Chapitre 1 - Variables, if et boucle while]({{site.baseurl}}/chapitre1/)<br>
[Chapitre 2 - Tableau, tuple et boucle for]({{site.baseurl}}/chapitre2/)<br>
